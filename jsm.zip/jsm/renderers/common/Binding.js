class Binding {

	constructor( name = '' ) {

		this.name = name;

	}

}

export default Binding;
